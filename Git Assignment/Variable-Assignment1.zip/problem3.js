var name = "Manoj Pandit";

var age = 21;

console.log(typeof(name));

console.log(typeof(age));

