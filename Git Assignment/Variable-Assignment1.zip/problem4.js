//printing report card 

let name = "Dᴇᴇᴘᴀᴋ Bɪsᴛ";
let school = "𝔾𝕠𝕧𝕥. 𝔹𝕠𝕪𝕤 𝕊𝕖𝕔𝕠𝕟𝕕𝕒𝕣𝕪 𝕊𝕔𝕙𝕠𝕠𝕝";
let grade = 12;
let section ="𝔸";
let rollno = 29;
let marks1 = 80;
let marks2 = 95;
let marks3 = 90;
console.log(name, school, grade, section, rollno, marks1,marks2, marks3);