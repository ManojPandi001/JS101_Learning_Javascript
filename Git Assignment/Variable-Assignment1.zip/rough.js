// let a = 3;
// let b = 2;

// console.log("sum is", a + b);
// console.log("sub is", a - b);
// console.log("mul is", a * b);
// console.log("div is", a / b);

//this is exponential operators

// let x = 10;

// let y = 20;
// console.log(x%y)

// let x = 3;
// let y = 1;
// console.log(((x+y)**(x-y))*((y**2)+(x**3)))

//>>>If conditional statement
// let a = 10;
// let b = 10;
// if(a==b){
//   console.log("both are equal");
// }
/*>>>> How to calculate discount     bracket will first solved */
// let bill = 4000;

// let mini_purchase = 3999;


// if(bill>mini_purchase){
//   console.log(bill-bill*0.10);

// }else{
//   console.log("Not eligible");
// }


// let budget = 5000;

// if(budget>=5000){
//   console.log("Dominos");
// }else if(budget>=2000){
//   console.log("dhaba");
// }else if(budget>=100){
//   console.log()
// }

// let a = 10;
// let c = ++a;
// let b = 10;
// let d = b++;
// console.log(a,b,c,d);

// let x = 1;
//   while(x<=12){
//   console.log(x);
//   if(x%3==0){
//     x=x+3;
//   }else{
//     x++
//   }
  
// }

// let i = 10;
// for(i=10; i>=1; i--){
//   console.log(i)
// }

// let sum=""
// for(let i=1; i<=10; i++){
  
//     sum +=i + "-*"

// }  console.log(sum)


// doubt======>
// let sum = 0;
// for(let i=1; i<=15; i++){
//   if(i%2==0 || i%5==0 ){
//     // sum+=i;
//     console.log(i)
//   }
  
// }
// calulate the average 
// let sum=0;
// let count=0;
// for (let i = 1;  i<=50; i++) {
//   if(i%2==0){
//     sum+=i;
//     count++
//   }
  
// }
// console.log(sum/count)

// for adding sum=0
// product
//   for(let i=1; i<=10; i++){
//   if(i%4==0){
//     break;
//   }console.log(i*2)
// }

// let n=5;
// let sum=1;
// for(let i =1; i<=n; i++){
//   sum=sum*i;
// }console.log(sum)

// let n = 6
// while(n<=9){
//   if(n%3==0){
//     n=n+2;
//   }else{
//     n++;
//   }console.log(++n)
// }

// let n =9
// let count1 =0
// let count2=0
// for(let i=1; i<=9; i++){
//   if(n%i==0){
//     count1++;
//   }else{
//     count2++;
//   }
// }console.log(count1,count2)

// let x =15
// let n =1
// let count=0
// while(n<=x){
//   if(x%n==0){
//     count++
//   }
//   n++;
// }console.log(count)
