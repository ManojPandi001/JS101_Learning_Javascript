let name = "Manoj Pandit "; // My name

let father_name = "Moti Pandit "; 

let mother_name = "Rekha Devi ";

console.log(name + father_name + mother_name); 